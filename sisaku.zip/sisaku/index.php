<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>メインメニュー</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/kognise/water.css@latest/dist/light.min.css">
    </head>
    <body>
<hr><h3>メインメニュー</h3><hr>
        <form action="insert.php">
            <input type="submit" value="入力フォームへ">
        </form>
        <form action="view.php">
            <input type="submit" value="出力フォームへ">
        </form>
    </body>
</html>